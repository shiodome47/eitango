# @shiodome47/word-gallery

絵と言葉のカードを並べて覚える、React の部品です。英単語と絵・手話の単語と絵など、「絵と言葉の組」なら何にでも使えます。

- 絵・言葉・意味のカードを、画面の幅に合わせて並べる（スマホで 2 列、広い画面で 3 列以上）
- **意味をかくす**／**単語をかくす** → タップで見る
- 絵を押すと**くわしい画面**（大きな絵・例文とその読み上げ・前へ／次へ。キーボードの ← → と Esc、指で横にはらっても動く）
- **読み上げ**（端末に入っている声。素材は要らない）
- **覚えた印**と、しぼり込み（すべて・まだ・覚えた）、まぜる
- カードが多いときは、**セット**に分けて選ぶ（セットごとの進み具合つき）
- 絵がまだ無いカードは、色つきの四角に字（絵文字など）を出す
- 明るい表示・暗い表示。文言は日本語が既定で、英語にもできる

## 入れ方

```bash
npm install @shiodome47/word-gallery
```

React 18・19 で使えます。ほかに要るものはありません（アイコンも中に持っています）。

## 1. そのまま使う

```tsx
import { useState } from 'react'
import { WordGallery, type WordItem } from '@shiodome47/word-gallery'
import '@shiodome47/word-gallery/style.css'

const items: WordItem[] = [
  { id: 'erupt', word: 'erupt', meaning: '噴火する', image: '/img/erupt.webp', example: 'The volcano erupted.', exampleMeaning: '火山が噴火した。' },
  { id: 'wither', word: 'wither', meaning: 'しおれる', placeholder: '🥀' }, // 絵が無いカード
]

export function Page() {
  const [learned, setLearned] = useState<string[]>([]) // 保存はアプリが行う
  return <WordGallery items={items} learned={learned} onLearnedChange={setLearned} />
}
```

**覚えた印はアプリが持ちます。** 部品は、印が変わるたびに新しい一覧（id の配列）を `onLearnedChange` に渡すだけです。
ブラウザの中・同期のサーバーなど、保存先はアプリが決めます。`onLearnedChange` を渡さなければ、印のボタンとしぼり込みは出ません。

### カード（`WordItem`）

| 名前 | 中身 |
|---|---|
| `id` | カードを見分ける名前（覚えた印はこれで持つので、あとから変えない） |
| `word` | 覚える言葉 |
| `meaning` | 意味 |
| `image` | 絵の URL（無くてもよい） |
| `alt` | 絵の説明（読み上げ用） |
| `placeholder` | 絵が無いときに大きく出す字（絵文字など）。無ければ言葉の 1 文字目 |
| `example`・`exampleMeaning` | 例文と、その意味（くわしい画面に出る） |
| `note` | 小さく出すひとこと（品詞など） |

アプリの項目を足したカードも、そのまま渡せます（`WordGallery<MyWord>`）。

## 2. 少し変える

| props | 中身 |
|---|---|
| `defaultHide` | はじめのかくし方。`'none'`（両方出す）・`'meaning'`・`'word'` |
| `defaultFilter` | はじめのしぼり込み。`'all'`・`'todo'`・`'learned'` |
| `toolbar` | 上の道具の行を出すか（`false` で出さない） |
| `lang` | 読み上げの言語（ふつうは `'en-US'`）。`false` で読み上げのボタンを出さない |
| `onSpeak` | 読み上げを自分で行う（録音した声を鳴らすなど）。`(item, what)` で、`what` は言葉（`'word'`）か例文（`'example'`） |
| `minColumnWidth` | 1 列の最小の幅（ふつうは `'10rem'`） |
| `renderDetailExtra` | くわしい画面の下に、アプリのものを足す（メモ・関連語など） |
| `labels` | 文言の差し替え（変えたいものだけ）。英語は `EN_LABELS` |
| `theme` | `'light'`・`'dark'`・`'system'`（ふつうは端末の設定に合わせる） |
| `className` | いちばん外の要素に足すクラス |

見た目は `.word-gallery` の中だけに効きます。色や大きさは変数で変えられます。

```css
.word-gallery {
  --wg-accent: #2563eb; /* 選んでいるボタン・覚えた印 */
  --wg-ratio: 1 / 1; /* 絵の縦横の割合（ふつうは 3 / 2） */
  --wg-word-size: 1.5rem;
}
```

### セットに分ける（`<WordSetPicker>`）

カードが多いときは、まとまり（セット）に分けて、上の帯で選べるようにします。帯には、セットごとの覚えた数が出ます。

```tsx
import { chunkItems, WordGallery, WordSetPicker } from '@shiodome47/word-gallery'

const sets = chunkItems(items, 12) // 12 枚ずつ。自分で組んでもよい（{ id, title, items }）
const [setId, setSetId] = useState<string | null>('1') // null は「すべて」。覚えておくのはアプリ
const shown = sets.find((s) => s.id === setId)?.items ?? items

<WordSetPicker sets={sets} value={setId} onChange={setSetId} learned={learned} />
<WordGallery key={setId} items={shown} learned={learned} onLearnedChange={setLearned} />
```

## 3. 組み立てる（計算だけ使う）

画面を自分で作るときは、計算だけ使えます。どれも渡したものを書き換えず、新しいものを返します。

- `toggleLearned(learned, id)`: 覚えた印を付ける・外す
- `filterItems(items, learned, filter)`: しぼり込む
- `progress(items, learned)`: `{ total, learned, todo }`
- `shuffleItems(items, seed)`: まぜる（同じ `seed` なら同じ順）
- `chunkItems(items, size)`: 決まった数ずつのセットに分ける
- `speak(text, lang)`・`canSpeak()`: 読み上げ。声は `pickVoice(voices, lang)` で選ぶ（端末に入っている声のうち、効果音のようなふざけた声を外し、聞きやすい声を優先する）
- `placeholderHue(word)`・`placeholderText(item)`: 絵が無いときの色あいと字

## 絵について

この部品は絵を作りません。絵の URL をもらって並べるだけです。
絵は 3:2 の枠に、はみ出したところを切って収めます（`--wg-ratio` で変えられます）。webp で、横 800px くらいあれば十分です。

## 動かしてみる

```bash
npm install
npm run dev
```

見本（`examples/web`）は、英検 1 級くらいの動詞 27 語です。絵は `examples/web/public/img`。`words.ts` の `prompt` に、絵にした場面を書いてあります。

### 6 枚組の絵を切り分ける

文字なし・すき間なしの 3×2 で作った 1 枚の画像を、1 語 1 枚に切り分けます（Pillow が要ります）。名前は左上から右へ。

```bash
python3 scripts/cut_sheet.py シート.webp examples/web/public/img scamper flounder contort clatter brandish hoard
```

公開の手順は [`PUBLISHING.md`](PUBLISHING.md)。
